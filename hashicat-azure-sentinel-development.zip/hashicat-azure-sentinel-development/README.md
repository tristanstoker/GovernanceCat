# hashicat
Hashicat: A terraform built application for use in Hashicorp workshops.

Includes the "Meow World" website. 😻

[![infrastructure-tests](https://github.com/hashicorp/hashicat-azure/actions/workflows/infrastructure-tests.yml/badge.svg)](https://github.com/hashicorp/hashicat-azure/actions/workflows/infrastructure-tests.yml)
